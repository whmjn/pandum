# resize: convert schedule.png -resize 100x100\> schedule100.png
# base64: - cat picture.png | base64 -w 0
# js insert: data:image/png;base64,<base64>
