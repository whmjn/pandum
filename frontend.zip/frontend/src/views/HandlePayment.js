import React from "react";

const HandlePayment = () => {
  return null;
};

export default HandlePayment;
