import React from "react";

const Oauth2 = (props) => {
  return <div>tmp</div>;
};

export default Oauth2;
