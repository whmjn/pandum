const data = {
  id: "8ccf0bec1fde018771ab685d2a40bd52",
  info: {
    url: "",
    name: "testing",
    description: "wut",
  },
  transforms: {},
  actions: {},
  type: "webhook",
  status: "uninitialized",
  running: false,
};

export default data;
