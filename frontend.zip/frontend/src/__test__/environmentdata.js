const data = [
  { name: "cloud", type: "cloud" },
  { name: "onprem", type: "onprem" },
];

export default data;
