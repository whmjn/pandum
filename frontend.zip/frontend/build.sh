npm run build
rm -rf ../backend/go-app/build
cp -r build/ ../backend/go-app/build
